﻿
namespace Employee.DTO
{
    public class EmployeesInfoResponseDTO : BaseResponseDTO
    {
        public EmployeeDTO Employee { get; set; }
    }
}
