﻿using System.Collections.Generic;

namespace Employee.DTO
{
    public class EmployeesResponseDTO : BaseResponseDTO
    {
        public List<EmployeeDTO> Employees { get; set; }
    }
}
