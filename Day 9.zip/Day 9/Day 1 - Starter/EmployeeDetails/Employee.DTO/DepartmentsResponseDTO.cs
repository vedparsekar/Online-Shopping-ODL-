﻿using System.Collections.Generic;

namespace Employee.DTO
{
    public class DepartmentsResponseDTO : BaseResponseDTO
    {
        public List<DepartmentDTO> Departments { get; set; }
    }
}
