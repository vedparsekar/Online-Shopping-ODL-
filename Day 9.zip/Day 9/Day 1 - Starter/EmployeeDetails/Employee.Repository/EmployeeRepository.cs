﻿using System.Collections.Generic;
using System.Data.Linq;
using System.Linq;
using Employee.Entities;

namespace Employee.Repository
{
    public interface IEmployeeRepository
    {
        IEnumerable<EMPLOYEE> GetEmployees();

        EMPLOYEE GetEmployee(int employeeId);

        IEnumerable<EMPLOYEE> GetEmployeesByDepartment(int departmentId);

        void InsertEmployee(EMPLOYEE newEmployee);
    }


    public class EmployeeRepository : IEmployeeRepository
    {
        /// <summary>
        /// Returns new instance of Repository
        /// </summary>
        public static IEmployeeRepository NewEmployeeRepository
        {
            get
            {
                return new EmployeeRepository();
            }
        }

        #region Interface Methods

        /// <summary>
        /// Return all Employees
        /// </summary>
        public IEnumerable<EMPLOYEE> GetEmployees()
        {
            using (EmployeeDataContext context = new EmployeeDataContext())
            {
                //Load Departments for employees
                DataLoadOptions options = new DataLoadOptions();
                options.LoadWith<EMPLOYEE>(emp => emp.DEPARTMENT);
                context.LoadOptions = options;

                return context.EMPLOYEEs.ToList();
            }
        }

        /// <summary>
        /// Return Employee by Id
        /// </summary>
        public EMPLOYEE GetEmployee(int employeeId)
        {
            using (EmployeeDataContext context = new EmployeeDataContext())
            {
                //Load Departments for employees
                DataLoadOptions options = new DataLoadOptions();
                options.LoadWith<EMPLOYEE>(emp => emp.DEPARTMENT);
                context.LoadOptions = options;

                return context.EMPLOYEEs.SingleOrDefault(emp => emp.EMPLOYEEID == employeeId);
            }
        }

        /// <summary>
        /// Returns List of Employees in a Department
        /// </summary>
        public IEnumerable<EMPLOYEE> GetEmployeesByDepartment(int departmentId)
        {
            using (EmployeeDataContext context = new EmployeeDataContext())
            {
                return context.EMPLOYEEs.Where(emp => emp.DEPARTMENTID == departmentId).ToList();
            }
        }

        /// <summary>
        /// Adds New Employee record 
        /// </summary>
        public void InsertEmployee(EMPLOYEE newEmployee)
        {
            using (EmployeeDataContext context = new EmployeeDataContext())
            {
                context.EMPLOYEEs.InsertOnSubmit(newEmployee);
                context.SubmitChanges();
            }
        }

        #endregion

    }
}
