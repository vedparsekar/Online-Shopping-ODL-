﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LooselyCoupledDemo
{
    public class Remote
    {
        private IDevice _anyDevice;

        public Remote(IDevice device)
        {
            _anyDevice = device;
        }

        public void Start()
        {
            _anyDevice.SwitchOn();
        }
    }
}
