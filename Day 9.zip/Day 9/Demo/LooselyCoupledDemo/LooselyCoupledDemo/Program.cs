﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LooselyCoupledDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Remote remoteControl = new Remote(new Television());
            remoteControl.Start();

            Console.ReadKey();

        }
    }
}
