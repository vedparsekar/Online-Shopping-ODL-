﻿using LINQQueries.DataModels;
using LINQQueries.Helper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LINQQueries
{
    public class Ordering
    {
        private static OrderContext context = new OrderContext();

        /// <summary>
        /// "This sample uses a compound orderby to sort a list of products, first by category, and then by unit price, from highest to lowest."
        /// </summary>
        public static void UsingQueryOperator()
        {
            var sortedProducts = from p in context.Products
                                 orderby p.Category, p.UnitPrice descending
                                 select p;

            ObjectPrinter.PrintCollection(sortedProducts);
        }

        public static void UsingLambda()
        {
            var sortedProducts = context.Products.OrderBy(p => p.Category)
                                                 .ThenByDescending(p => p.UnitPrice);

            ObjectPrinter.PrintCollection(sortedProducts);
        }
    }
}
