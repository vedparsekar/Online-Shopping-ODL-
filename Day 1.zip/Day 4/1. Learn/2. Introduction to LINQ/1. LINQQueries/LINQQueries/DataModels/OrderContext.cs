﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LINQQueries.DataModels
{
    public class OrderContext
    {
        public OrderContext()
        {
            Customers = new List<Customer>
            {
                new Customer { CustomerId=1, FirstName="Carlos", LastName="Soltero", City="Mapusa", State="Goa", Country="India", Phone="999999999" },
                new Customer { CustomerId=2, FirstName="Monica", LastName="Federle", City="Panjim", State="Goa", Country="India", Phone="999999999" },
                new Customer { CustomerId=3, FirstName="Neola", LastName="Schneider", City="Panjim", State="Goa", Country="India", Phone="999999999" },
                new Customer { CustomerId=4, FirstName="Allen", LastName="Rosenblatt", City="Mapusa", State="Goa", Country="India", Phone="999999999" },
                new Customer { CustomerId=5, FirstName="Sylvia", LastName="Foulston", City="Mapusa", State="Goa", Country="India", Phone="999999999" }
            };

            Products = new List<Product>
            {
                 new Product { ProductId = 1, ProductName = "Chai", Category = "Beverages", UnitPrice = 18.0000M, UnitsInStock = 39 },
                    new Product { ProductId = 2, ProductName = "Chang", Category = "Beverages", UnitPrice = 19.0000M, UnitsInStock = 17 },
                    new Product { ProductId = 3, ProductName = "Aniseed Syrup", Category = "Condiments", UnitPrice = 10.0000M, UnitsInStock = 13 },
                    new Product { ProductId = 4, ProductName = "Chef Anton's Cajun Seasoning", Category = "Condiments", UnitPrice = 22.0000M, UnitsInStock = 53 },
                    new Product { ProductId = 5, ProductName = "Chef Anton's Gumbo Mix", Category = "Condiments", UnitPrice = 21.3500M, UnitsInStock = 0 },
                    new Product { ProductId = 6, ProductName = "Grandma's Boysenberry Spread", Category = "Condiments", UnitPrice = 25.0000M, UnitsInStock = 120 },
                    new Product { ProductId = 7, ProductName = "Uncle Bob's Organic Dried Pears", Category = "Produce", UnitPrice = 30.0000M, UnitsInStock = 15 },
                    new Product { ProductId = 8, ProductName = "Northwoods Cranberry Sauce", Category = "Condiments", UnitPrice = 40.0000M, UnitsInStock = 6 },
                    new Product { ProductId = 9, ProductName = "Mishi Kobe Niku", Category = "Meat/Poultry", UnitPrice = 97.0000M, UnitsInStock = 29 },
                    new Product { ProductId = 10, ProductName = "Ikura", Category = "Seafood", UnitPrice = 31.0000M, UnitsInStock = 31 },
                    new Product { ProductId = 11, ProductName = "Queso Cabrales", Category = "Dairy Products", UnitPrice = 21.0000M, UnitsInStock = 22 },
                    new Product { ProductId = 12, ProductName = "Queso Manchego La Pastora", Category = "Dairy Products", UnitPrice = 38.0000M, UnitsInStock = 86 },
                    new Product { ProductId = 13, ProductName = "Konbu", Category = "Seafood", UnitPrice = 6.0000M, UnitsInStock = 24 },
                    new Product { ProductId = 14, ProductName = "Tofu", Category = "Produce", UnitPrice = 23.2500M, UnitsInStock = 35 },
                    new Product { ProductId = 15, ProductName = "Genen Shouyu", Category = "Condiments", UnitPrice = 15.5000M, UnitsInStock = 39 },
                    new Product { ProductId = 16, ProductName = "Pavlova", Category = "Confections", UnitPrice = 17.4500M, UnitsInStock = 29 },
                    new Product { ProductId = 17, ProductName = "Alice Mutton", Category = "Meat/Poultry", UnitPrice = 39.0000M, UnitsInStock = 0 },
                    new Product { ProductId = 18, ProductName = "Carnarvon Tigers", Category = "Seafood", UnitPrice = 62.5000M, UnitsInStock = 42 },
                    new Product { ProductId = 19, ProductName = "Teatime Chocolate Biscuits", Category = "Confections", UnitPrice = 9.2000M, UnitsInStock = 25 },
                    new Product { ProductId = 20, ProductName = "Sir Rodney's Marmalade", Category = "Confections", UnitPrice = 81.0000M, UnitsInStock = 40 },
                    new Product { ProductId = 21, ProductName = "Sir Rodney's Scones", Category = "Confections", UnitPrice = 10.0000M, UnitsInStock = 3 },
                    new Product { ProductId = 22, ProductName = "Gustaf's Knäckebröd", Category = "Grains/Cereals", UnitPrice = 21.0000M, UnitsInStock = 104 },
                    new Product { ProductId = 23, ProductName = "Tunnbröd", Category = "Grains/Cereals", UnitPrice = 9.0000M, UnitsInStock = 61 },
                    new Product { ProductId = 24, ProductName = "Guaraná Fantástica", Category = "Beverages", UnitPrice = 4.5000M, UnitsInStock = 20 },
                    new Product { ProductId = 25, ProductName = "NuNuCa Nuß-Nougat-Creme", Category = "Confections", UnitPrice = 14.0000M, UnitsInStock = 76 },
                    new Product { ProductId = 26, ProductName = "Gumbär Gummibärchen", Category = "Confections", UnitPrice = 31.2300M, UnitsInStock = 15 },
                    new Product { ProductId = 27, ProductName = "Schoggi Schokolade", Category = "Confections", UnitPrice = 43.9000M, UnitsInStock = 49 },
                    new Product { ProductId = 28, ProductName = "Rössle Sauerkraut", Category = "Produce", UnitPrice = 45.6000M, UnitsInStock = 26 },
                    new Product { ProductId = 29, ProductName = "Thüringer Rostbratwurst", Category = "Meat/Poultry", UnitPrice = 123.7900M, UnitsInStock = 0 },
                    new Product { ProductId = 30, ProductName = "Nord-Ost Matjeshering", Category = "Seafood", UnitPrice = 25.8900M, UnitsInStock = 10 },
 
            };

            Orders = new List<Order>
            {
                new Order { OrderId=1, CustomeId=1, OrderDate=new DateTime(2012, 5, 12), RequiredDate=new DateTime(2012, 7, 12)},
                new Order { OrderId=2, CustomeId=2, OrderDate=new DateTime(2012, 2, 22), RequiredDate=new DateTime(2012, 3, 22)},
                new Order { OrderId=3, CustomeId=2, OrderDate=new DateTime(2011, 12, 4), RequiredDate=new DateTime(2012, 2, 4)},
                new Order { OrderId=4, CustomeId=1, OrderDate=new DateTime(2011, 3, 17), RequiredDate=new DateTime(2011, 4, 11)},
                new Order { OrderId=5, CustomeId=1, OrderDate=new DateTime(2012, 6, 7), RequiredDate=new DateTime(2012, 7, 10)},
            };

            OrderDetails = new List<OrderDetail>
            {
                new OrderDetail{ OrderId=1, ProductId=1, Quantity=7},
                 new OrderDetail{ OrderId=1, ProductId=2, Quantity=10},
                  new OrderDetail{ OrderId=1, ProductId=3, Quantity=3}
            };

            PetOwners = new List<PetOwner>
            {
                new PetOwner { Name="Higa, Sidney", Pets = new List<string>{ "Scruffy", "Sam" } },
                new PetOwner { Name="Ashkenazi, Ronen", Pets = new List<string>{ "Walker", "Sugar" } },
                new PetOwner { Name="Price, Vernette", Pets = new List<string>{ "Scratches", "Diesel" } } 
            };
        }

        public List<Customer> Customers { get; set; }
        public List<Product> Products { get; set; }
        public List<Order> Orders { get; set; }
        public List<OrderDetail> OrderDetails { get; set; }
        public List<PetOwner> PetOwners { get; set; }

    }
}
