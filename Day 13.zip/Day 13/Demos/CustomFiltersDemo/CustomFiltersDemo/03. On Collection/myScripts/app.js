﻿var app = angular.module("DemoApp", []);

app.filter('startsWithLetter', function () {
    return function (items, letter) {

        var filtered = [];
        var letterMatch = new RegExp(letter, 'i');

        for (var i = 0; i < items.length; i++) {
            var item = items[i];
            if (letterMatch.test(item.substring(0, 1))) {
                filtered.push(item);
            }
        }

        return filtered;
    };
});



app.controller('PersonController', function ($scope) {
    $scope.friends = [
         'Andrew',
         'Will',
         'Mark',
         'Alice',
         'Todd',
    ];
});