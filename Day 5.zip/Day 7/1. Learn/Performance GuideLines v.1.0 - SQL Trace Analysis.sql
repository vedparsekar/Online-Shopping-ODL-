-- Get Row Data
--select * from trc_live_16Jul where RowNumber in(921,899)
--select * from trc_live_16Jul where textdata like '%USP_GET_ALL_PACKAGE_SERVICE_SEARCH%'
--select top 100 duration/1000, * from trc_live_16Jul where duration > 0 order by duration desc 

-- SELECT @@SPID

-- Get list of SP's for which duration is large
select distinct case when charindex('usp_',cast(textdata as varchar(8000)), 0)<= 0 then ''else 
	substring(cast(textdata as varchar(8000)),charindex('usp_',cast(textdata as varchar(8000)), 0), charindex(char(32),cast(textdata as varchar(8000)), charindex('usp_',cast(textdata as varchar(8000)), 0))-charindex('usp_',cast(textdata as varchar(8000)), 0))
		end as pos  from trc_live_16Jul where textdata is not null and duration/1000000  >=2 --order by cast(textdata as varchar(max))

-- DURATION - Get details for queries  where duration is large
select cast(TextData as varchar(35)) textData, MIN(rownumber) rownum , 
COUNT(*) times, SUM(duration)/1000 totaltimeMS,AVG(duration)/1000 AvgMS, Min(duration)/1000 MinMS,Max(duration)/1000 MaxMS,
AVG(reads) AvgReads, SUM(reads) TotalReads,Min(reads) MinREADS,Max(reads) MAXREADS,
AVG(cpu) avgCPU, SUM(cpu) totalCPU , Min(CPU) MinCPU,Max(CPU) MAXCPU
from trc_live_16Jul where duration > 0
group by cast(TextData as varchar(35))
--having SUM(duration )>1000
order by SUM(duration ) desc

-- READS - Get details for queries  where reads is large
select cast(TextData as varchar(1000)), MIN(rownumber) rownum, 
COUNT(*) times,  SUM(duration)/1000 totaltimeMS, AVG(duration)/1000 AvgMS,Min(duration)/1000 MinMS,Max(duration)/1000 MaxMS,
AVG(reads) AvgReads, SUM(reads) TotalReads,Min(reads) MinREADS,Max(reads) MAXREADS,
AVG(cpu) avgCPU, SUM(cpu) totalCPU , Min(CPU) MinCPU,Max(CPU) MAXCPU
from trc_live_16Jul
group by cast(TextData as varchar(1000))
having SUM(reads )>1000
order by SUM(reads ) desc


-- CPU - Get details for queries  where CPU is large
select cast(TextData as varchar(1000)) , MIN(rownumber) rownum, 
COUNT(*) times, SUM(duration)/1000 totaltimeMS,AVG(duration)/1000 AvgMS, Min(duration)/1000 MinMS,Max(duration)/1000 MaxMS,
AVG(reads) AvgReads, SUM(reads) TotalReads,Min(reads) MinREADS,Max(reads) MAXREADS,
AVG(cpu) avgCPU, SUM(cpu) totalCPU, Min(CPU) MinCPU,Max(CPU) MAXCPU
from trc_live_16Jul
group by cast(TextData as varchar(1000))
having SUM(cpu )>100
order by SUM(cpu ) desc