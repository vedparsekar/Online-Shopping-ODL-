﻿using System.Collections.Generic;
using System.Data.Linq;
using System.Linq;
using Employee.Entities;

namespace Employee.Repository
{
    public interface IDepartmentRepository
    {
        IEnumerable<DEPARTMENT> GetDepartments();

        DEPARTMENT GetDepartment(int departmentId);
    }

    public class DepartmentRepository : IDepartmentRepository
    {
        /// <summary>
        /// Returns new instance of Repository
        /// </summary>
        public static IDepartmentRepository NewDepartmentRepository
        {
            get
            {
                return new DepartmentRepository();
            }
        }

        #region Interface Methods
        /// <summary>
        /// Return all Departments
        /// </summary>
        public IEnumerable<DEPARTMENT> GetDepartments()
        {
            using (EmployeeDataContext context = new EmployeeDataContext())
            {
                return context.DEPARTMENTs.ToList();
            }
        }

        /// <summary>
        /// Returns Department Details
        /// </summary>
        public DEPARTMENT GetDepartment(int departmentId)
        {
            using (EmployeeDataContext context = new EmployeeDataContext())
            {
                return context.DEPARTMENTs.SingleOrDefault(dept => dept.DEPARTMENTID == departmentId);
            }
        }
        #endregion
    }
}
