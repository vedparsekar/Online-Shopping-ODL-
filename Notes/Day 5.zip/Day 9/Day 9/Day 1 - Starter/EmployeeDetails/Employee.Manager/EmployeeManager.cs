﻿using System;
using System.Linq;
using Employee.Repository;
using Employee.DTO;
using Employee.Entities;

namespace Employee.Manager
{
    public interface IEmployeeManager
    {
        EmployeesResponseDTO GetEmployees();

        EmployeesInfoResponseDTO GetEmployee(EmployeesInfoRequestDTO request);

        EmployeesResponseDTO InsertEmployee(EmployeeDTO request);
    }

    public class EmployeeManager : IEmployeeManager
    {
        private readonly IEmployeeRepository _employeeRepository;


        public EmployeeManager(IEmployeeRepository employeeRepository)
        {
            _employeeRepository = employeeRepository;
        }

        public static IEmployeeManager NewEmployeeManager
        {
            get
            {
                return new EmployeeManager(EmployeeRepository.NewEmployeeRepository);
            }
        }

        #region Interface Methods

        /// <summary>
        /// Return All Employee's Details
        /// </summary>
        public EmployeesResponseDTO GetEmployees()
        {
            EmployeesResponseDTO employeeDTO = new EmployeesResponseDTO();

            try
            {
                employeeDTO.Employees = (from employee in _employeeRepository.GetEmployees()
                                         select new EmployeeDTO
                                         {
                                             EmployeeId = employee.EMPLOYEEID,
                                             EmployeeName = employee.EMPLOYEENAME,
                                             Salary = employee.EMPLOYEESALARY ?? 0.0M,
                                             DepartmentId = employee.DEPARTMENTID,
                                             DepartmentName = employee.DEPARTMENT != null ? employee.DEPARTMENT.DEPARTMENTNAME : null
                                         }).ToList();

                employeeDTO.IsSuccess = true;

            }
            catch (Exception ex)
            {
                //Log Error
                employeeDTO.ErrorNo = -999;
                employeeDTO.Message = ex.Message;
            }

            return employeeDTO;
        }

        /// <summary>
        /// Return Employee by Id
        /// </summary>
        public EmployeesInfoResponseDTO GetEmployee(EmployeesInfoRequestDTO request)
        {
            EmployeesInfoResponseDTO employeeDTO = new EmployeesInfoResponseDTO();

            try
            {
                var employee = _employeeRepository.GetEmployee(request.EmployeeId);

                if (employee != null)
                {
                    employeeDTO.Employee = new EmployeeDTO();
                    employeeDTO.Employee.EmployeeId = employee.EMPLOYEEID;
                    employeeDTO.Employee.EmployeeName = employee.EMPLOYEENAME;
                    employeeDTO.Employee.Salary = employee.EMPLOYEESALARY ?? 0.0M;
                    employeeDTO.Employee.DepartmentId = employee.DEPARTMENTID;
                    employeeDTO.Employee.DepartmentName = employee.DEPARTMENT != null ? employee.DEPARTMENT.DEPARTMENTNAME : null;

                    employeeDTO.IsSuccess = true;
                }
                else
                {
                    employeeDTO.ErrorNo = -999;
                    employeeDTO.Message = "No record Found";
                }

            }
            catch (Exception ex)
            {
                //Log Error
                employeeDTO.ErrorNo = -999;
                employeeDTO.Message = ex.Message;
            }

            return employeeDTO;
        }

        #endregion


        public EmployeesResponseDTO InsertEmployee(EmployeeDTO request)
        {
            EmployeesResponseDTO employeeDTO = new EmployeesResponseDTO();

            try
            {
                EMPLOYEE employee = new EMPLOYEE();
                employee.EMPLOYEENAME = request.EmployeeName;
                employee.EMPLOYEESALARY = request.Salary;
                employee.DEPARTMENTID = request.DepartmentId;
                _employeeRepository.InsertEmployee(employee);
                employeeDTO.IsSuccess = true;

            }
            catch (Exception ex)
            {
                //Log Error
                employeeDTO.ErrorNo = -999;
                employeeDTO.Message = ex.Message;
            }

            return employeeDTO;
        }

    }
}
