﻿using System;
using System.Linq;
using Employee.Repository;
using Employee.DTO;

namespace Employee.Manager
{
    public interface IDepartmentManager
    {
        DepartmentsResponseDTO GetDepartments();

        DepartmentInfoResponseDTO GetDepartment(DepartmentInfoRequestDTO request);
    }

    public class DepartmentManager : IDepartmentManager
    {
        private readonly IDepartmentRepository _departmentRepository;


        public DepartmentManager(IDepartmentRepository departmentRepository)
        {
            _departmentRepository = departmentRepository;
        }


        public static IDepartmentManager NewDepartmentManager
        {
            get
            {
                return new DepartmentManager(DepartmentRepository.NewDepartmentRepository);
            }
        }

        #region Interface Methods

        /// <summary>
        /// Return All Departments
        /// </summary>
        public DepartmentsResponseDTO GetDepartments()
        {
            DepartmentsResponseDTO departmentsDTO = new DepartmentsResponseDTO();

            try
            {
                departmentsDTO.Departments = (from department in _departmentRepository.GetDepartments()
                                              select new DepartmentDTO
                                            {
                                                DepartmentId = department.DEPARTMENTID,
                                                DepartmentName = department.DEPARTMENTNAME
                                            }).ToList();

                departmentsDTO.IsSuccess = true;
            }
            catch (Exception ex)
            {
                //Log Error
                departmentsDTO.ErrorNo = -999;
                departmentsDTO.Message = ex.Message;
            }

            return departmentsDTO;
        }

        /// <summary>
        /// Get Department and List of Employees in a department
        /// </summary>
        public DepartmentInfoResponseDTO GetDepartment(DepartmentInfoRequestDTO request)
        {
            DepartmentInfoResponseDTO departmentDTO = null;

            try
            {
                var department = _departmentRepository.GetDepartment(request.DepartmentId);

                if (department != null)
                {
                    departmentDTO.Department = new DepartmentDTO();
                    departmentDTO.Department.DepartmentId = department.DEPARTMENTID;
                    departmentDTO.Department.DepartmentName = department.DEPARTMENTNAME;

                    departmentDTO.IsSuccess = true;
                }
                else
                {
                    departmentDTO.ErrorNo = -999;
                    departmentDTO.Message = "No record Found";
                }
            }
            catch (Exception ex)
            {
                //Log Error
                departmentDTO.ErrorNo = -999;
                departmentDTO.Message = ex.Message;
            }

            return departmentDTO;

        }
        #endregion
    }
}
