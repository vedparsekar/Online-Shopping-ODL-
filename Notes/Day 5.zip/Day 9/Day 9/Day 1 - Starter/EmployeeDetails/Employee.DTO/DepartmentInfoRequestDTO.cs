﻿
namespace Employee.DTO
{
    public class DepartmentInfoRequestDTO 
    {
        public int DepartmentId { get; set; }
    }
}
