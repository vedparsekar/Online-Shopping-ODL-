﻿
namespace Employee.DTO
{
    public class DepartmentInfoResponseDTO : BaseResponseDTO
    {
        public DepartmentDTO Department { get; set; }
    }
}
