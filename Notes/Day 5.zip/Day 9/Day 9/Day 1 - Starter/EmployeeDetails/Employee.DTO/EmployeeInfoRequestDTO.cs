﻿
namespace Employee.DTO
{
    public class EmployeesInfoRequestDTO 
    {
        public int  EmployeeId { get; set; }
    }
}
