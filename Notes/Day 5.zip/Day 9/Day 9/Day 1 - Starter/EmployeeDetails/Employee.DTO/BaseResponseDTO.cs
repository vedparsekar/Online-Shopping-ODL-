﻿using System;

namespace Employee.DTO
{
    [Serializable]
    public class BaseResponseDTO
    {
        public int ErrorNo { get; set; }
        public bool IsSuccess { get; set; }
        public string Message { get; set; }
    }
}
