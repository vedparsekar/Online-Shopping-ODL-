﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Employee.DTO;
using Employee.Manager;


namespace MVCEmployeeDetails.Controllers
{
    public class EmployeeController : Controller
    {
        EmployeeDTO Employees;
        private IEmployeeManager _employeeManager;
        public EmployeeController()
        {
            _employeeManager = EmployeeManager.NewEmployeeManager;
        }
        //
        // GET: /Employee/

        public ActionResult Index()
        {
            EmployeesResponseDTO objResponse = _employeeManager.GetEmployees();
            List<EmployeeDTO> AllEmployee = objResponse.Employees;
            return View(AllEmployee);
        }

        public ActionResult Details(int id)
        {
            EmployeesResponseDTO objResponse = _employeeManager.GetEmployees();
            List<EmployeeDTO> AllEmployee = objResponse.Employees;
            EmployeeDTO employee = AllEmployee.SingleOrDefault(e => e.EmployeeId == id);
            return View("Details", employee);       
        }

        [HttpGet]
        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Create(EmployeeDTO employee)
        {
           EmployeesResponseDTO objResponse= _employeeManager.InsertEmployee(employee);
           return View();
        }
    }
}
