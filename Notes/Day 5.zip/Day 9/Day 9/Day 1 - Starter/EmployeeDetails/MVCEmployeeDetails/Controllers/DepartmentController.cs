﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Employee.DTO;
using Employee.Manager;

namespace MVCEmployeeDetails.Controllers
{
    public class DepartmentController : Controller
    {
        //
        // GET: /Department/
        private IDepartmentManager _departmentManager;

        public DepartmentController()
        {
            _departmentManager = DepartmentManager.NewDepartmentManager;
        }

        public PartialViewResult _getDepartment()
        {
            DepartmentsResponseDTO responseDTO = _departmentManager.GetDepartments();
            List<DepartmentDTO> AllDepartments = responseDTO.Departments;
            return PartialView(AllDepartments);
        }

        public ActionResult Index()
        {
            return View();
        }

    }
}
