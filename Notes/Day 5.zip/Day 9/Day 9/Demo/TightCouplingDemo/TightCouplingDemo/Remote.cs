﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TightCouplingDemo
{
    public class Remote
    {
        private Television _tv;

        public Remote()
        {
            _tv = new Television();
        }

        public void Start()
        {
            _tv.SwitchOn();
        }
    }
}


//The Control can only control the TV, cannot control other devices.