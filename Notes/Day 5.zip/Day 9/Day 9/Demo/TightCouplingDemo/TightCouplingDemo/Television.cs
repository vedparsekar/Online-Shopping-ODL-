﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TightCouplingDemo
{
    public class Television 
    {
        public void SwitchOn()
        {
            Console.WriteLine("Television Started");
        }
    }
}
