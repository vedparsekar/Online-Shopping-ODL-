﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MVCDemo.Models;

namespace MVCDemo.Controllers
{
    public class HomeController : Controller
    {
        #region Data Members
        
        private List<Employee> employees;

        public HomeController()
        {
            employees = new List<Employee>()
            {
                new Employee { EmployeeId = 1, FirstName = "Jack", LastName = "Smith", Salary = 4500.50 },
                new Employee { EmployeeId = 2, FirstName = "Sam", LastName = "Smith", Salary = 9500.50 },
                new Employee { EmployeeId = 3, FirstName = "Ken", LastName = "Brown", Salary = 2500.50 },
                new Employee { EmployeeId = 4, FirstName = "Pam", LastName = "White", Salary = 7500.50 },
                new Employee { EmployeeId = 5, FirstName = "Tom", LastName = "Jones", Salary = 3500.50 },
            };
        }

        #endregion

        public ActionResult Index()
        {
            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }

        #region 02. Return Type

        public DateTime CurrentDateTime()
        {
            return DateTime.Now;
        } 

        #endregion

        #region 03. Using Model
       
        public ActionResult Employees()
        {
            return View(employees); 
        }
        
        #endregion

        #region 04. Using Parameter's

        public ActionResult Details(int id)
        {
            Employee employee = employees.SingleOrDefault(e => e.EmployeeId == id);

            //return View(employee); 
            return View("EmployeeDetails", employee);
        }

        #endregion


    }
}