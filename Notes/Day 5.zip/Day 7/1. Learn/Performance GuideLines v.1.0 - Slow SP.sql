IF EXISTS (SELECT 1 FROM sysobjects WHERE object_name(ID) = 'usp_Get_Booked_options_test' AND xtype = 'p')
	DROP PROCEDURE usp_Get_Booked_options_test
GO

/*
    BY:- DEVELOPER A 
	REVIEWD BY: PL <Name>
    On:- 12/12/13
    Desc:- This Sp is a example of Slow performning SP, with very bad coding example.
   	SP HAS TO GET ALL THE OPTIONS DETAILS FOR ALL BOOKINGS WHICH ARE BETWEEN THE OPTION DATE-RANGE PASSED

    Points to check now
    1. Add Set No Count ON
    2. Move All declarations in the Begining.
    3. Also if variables are named wrongly you can go ahead and name them properly.
    4. Whichever area you are working on, if there are no COMMENTS what that line is doing, add it.
    5. As you try to undestand and going through SP, if its not formated. Foramt it so that atleast its readable.
    
    6. Now your SP is readble and can be optimised easily.
    7. check in profiler which Query is taking time.
    8. In case if you have any loop, profiler cant show total time for loop. So print timings before and after loops or big queries.
    9. Remove loop, or try to change the logic of loop. In new code do not add Loops.
    10. Avoid SET keyword.
    11. Remove Subqueries.
    12. remove unused tables from joins.
    13. remove unwated variables.
    
    13. last once all logical and formating work is done we can check for Indexes.
    -- Check in Profiler. Execution plan
    -- SP advantage over inline Query.
    
    
*/
CREATE PROCEDURE usp_Get_Booked_options_test 
	@BookingStartDate DATETIME,--> 3. Wrong Name, shoudl be option date, Naming convention not used 
	@I_BookingEndDate VARCHAR(8000) --> 3. Wrong Name, shoudl be option date, Naming convention not used Why varchar? will i tneed 8000 chars?
AS
BEGIN
	DECLARE @i INT

	SELECT TOP 1 @i = BOOKEDOPTIONID
	FROM BOOKED_OPTION
	WHERE BOOKEDOPTIONINDATE BETWEEN @BookingStartDate AND CAST(@I_BookingEndDate AS DATETIME)
	ORDER BY BOOKEDOPTIONID ASC

	DECLARE @bkdop TABLE ( BID INT, BKID INT, reff VARCHAR(120), BSID INT)

	DECLARE @ORGANISATIONSETTINGSDEFCURRENCYID INT
	DECLARE @ORGANISATIONSETTINGSSHOWAVAILABLEONLY BIT
	DECLARE @MARKUPPERCENTAGESETTING INT

	-- REVIEW COMMENT - WHY DO YOU NEED A LOOP? THIS CAN EASILY BE FETCH USING JOINS AND MULTIPEL TABLE VARIABLES

	WHILE EXISTS (SELECT TOP 1 * FROM BOOKED_OPTION
					WHERE BOOKEDOPTIONINDATE BETWEEN @BookingStartDate AND CAST(@I_BookingEndDate AS DATETIME)
						AND BOOKEDOPTIONID > @i ORDER BY BOOKEDOPTIONID ASC)
	BEGIN
		-- REVIEW COMMENT - BELOW VARIABLE NAMES ARE UNCLEAR AND NOT FOLLOWING NAMING CONVENTIONS. ALSO SHOUDL BE OUTSIDE LOOP

		DECLARE @bID INT
		DECLARE @bkid INT
		DECLARE @reff VARCHAR(100)
		DECLARE @bsid INT

		-- REVIEW COMMENT - USE ONLY A SINGLE QUERY TO FETCH ORGANISATION SETTINGS. ALSO USE NOLOCK 
		-- ALSO THE QUERY SHOULD BE OUTSIDE LOOPS AS IT IS FETCHING SAME DETAILS EVERYTIME. 
		SELECT @ORGANISATIONSETTINGSDEFCURRENCYID = ORGANISATIONSETTINGSDEFCURRENCYID 
			FROM ORGANISATION_SETTINGS OS, ORGANISATION O WHERE O.ORGANISATIONID = OS.ORGANISATIONID AND O.PARENT_ORGANISATIONID IS NULL     

		SELECT @ORGANISATIONSETTINGSSHOWAVAILABLEONLY = ORGANISATIONSETTINGSSHOWAVAILABLEONLY 
			FROM ORGANISATION_SETTINGS OS, ORGANISATION O WHERE O.ORGANISATIONID = OS.ORGANISATIONID AND O.PARENT_ORGANISATIONID IS NULL     

		SELECT @MARKUPPERCENTAGESETTING = MARKUPPERCENTAGESETTING 
			FROM ORGANISATION_SETTINGS OS, ORGANISATION O WHERE O.ORGANISATIONID = OS.ORGANISATIONID AND O.PARENT_ORGANISATIONID IS NULL     


		
		-- 11
		SELECT @bID = BOOKEDOPTIONID
		FROM Booked_option
		WHERE BOOKEDOPTIONID = @i

		SET @bkid = (SELECT bookingid FROM BOOKING
						WHERE bookingid IN (SELECT bookingid FROM BOOKED_SERVICE WHERE bookedserviceid IN (
								SELECT bookedserviceid FROM booked_option WHERE BOOKEDOPTIONID IN (@bID)))
						)

		WAITFOR DELAY '00:00:00.500'

		SELECT @reff = bookingreferencenumber
		FROM BOOKING
		WHERE BOOKINGID = @bkid

		SET @bsid = (
				SELECT DISTINCT x.bookedserviceid
				FROM BOOKED_SERVICE x1
					,BOOKED_OPTION x
					,BOOKED_CHILD_RATE r
					,BOOKING b
				WHERE x1.BOOKEDSERVICEID = x.BOOKEDSERVICEID
					AND r.BOOKEDOPTIONID = x.BOOKEDOPTIONID
					AND b.BOOKINGID = x1.BOOKINGID
					AND b.BOOKINGREFERENCENUMBER = @reff
					AND x.BOOKEDOPTIONID = @bID
				)

		INSERT INTO @bkdop
		VALUES (@bID, @bkid, @reff, @bsid)

		SELECT TOP 1 @i = BOOKEDOPTIONID
		FROM BOOKED_OPTION
		WHERE BOOKEDOPTIONINDATE BETWEEN @BookingStartDate AND CAST(@I_BookingEndDate AS DATETIME) AND BOOKEDOPTIONID > @i
		ORDER BY BOOKEDOPTIONID ASC

		SET @bID = NULL
		SET @bkid = NULL
		SET @reff = NULL
		SET @bsid = NULL
	END

	SELECT * FROM @bkdop
END
GO

EXEC usp_Get_Booked_options_test '1-Jan-2013'
	,'1-Jan-2013'
GO

