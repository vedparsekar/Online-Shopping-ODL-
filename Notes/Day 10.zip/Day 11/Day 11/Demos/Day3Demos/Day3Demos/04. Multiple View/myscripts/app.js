﻿var sampleApp = angular.module('sampleApp', ['ui.router']);

sampleApp.config(['$stateProvider', function ($stateProvider) {
    $stateProvider
        .state('home',
          {
              url: "/home",
              views: {
                  "first": {
                      template: "<h1>Home state -First View"
                  },
                  "second": {
                      template: "<h1>Home state -Second View"
                  }

              }

          })

 
     .state('about',
            {
                url: "/about",
                views: {
                    "first": {
                        template: "<h1>About state -First View"
                    },
                    "second": {
                        template: "<h1>About state -Second View"
                    }

                }

            })

}]);
