﻿var app = angular.module("DemoApp", []);

// Setup the filter
app.filter('ordinal', function () {

    // Create the return function
    return function (number) {

        // Ensure that the passed in data is a number
        if (isNaN(number) || number < 1) {
            // If the data is not a number or is less than one (thus not having a cardinal value) return it unmodified.
            return number;

        } else {

            var lastDigit = number % 10;

            if (lastDigit === 1) {
                return number + 'st'
            } else if (lastDigit === 2) {
                return number + 'nd'
            } else if (lastDigit === 3) {
                return number + 'rd'
            } else if (lastDigit > 3) {
                return number + 'th'
            }

        }
    }
});