﻿/// <reference path="C:\Users\ruena\Desktop\MVC + Angular JS\Day 4\Demos\Day4Demos\Day4Demos\Scripts/angular.js" />

angular.module('directiveDemoApp', [])

.controller('CountCtrl', function () {
    this.count = 4;
})

