﻿// before
angular.module('myApp', [])
  .controller('personController', function () {
      var self = this;
      self.firstName = 'John';
      self.lastName = "Smith";
      self.hobbies = ["Painting", "Football", "Travelling"];

      self.getFullName = function () {
          self.fullName = self.firstName + " " + self.lastName
      }
  });


