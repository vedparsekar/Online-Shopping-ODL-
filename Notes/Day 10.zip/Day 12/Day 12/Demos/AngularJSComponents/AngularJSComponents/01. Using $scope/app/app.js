﻿// before
angular.module('myApp',[])
  .controller('PersonController', function ($scope) {
      $scope.firstName = 'John';
      $scope.lastName = "Smith";
      $scope.hobbies = ["Painting", "Football", "Travelling"];
  });


