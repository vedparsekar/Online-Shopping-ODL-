﻿/// <reference path="C:\Users\ruena\Documents\Visual Studio 2013\Projects\Ruena\Test Task\AngularJSComponents\AngularJSComponents\Scripts/angular.js" />

angular.module('directiveDemoApp', [])

.controller('CountCtrl', function () {
    this.count = 4;
})

.directive('counter', function () {
    return {
        scope: {},
        bindToController: {
            count: '='
        },
        controller: function () {
            this.increment = function increment() {
                this.count++;
            };

            this.decrement = function decrement() {
                this.count--;
            };
        },
        controllerAs: 'counter',
        templateUrl: "templates/counter-template.html"
    };
});