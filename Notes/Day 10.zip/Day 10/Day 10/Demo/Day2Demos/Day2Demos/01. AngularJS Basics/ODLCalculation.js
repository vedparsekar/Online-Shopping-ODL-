﻿/// <reference path="../Scripts/angular.js" />
var app = angular.module("ODL.Calc", []);
app.controller("NumberController", function ($scope) {
    $scope.firstnumber = 100;
    $scope.secondnumber = 300;
    //console.log($scope);
    $scope.GetResult = function () {
        //$scope.Add = $scope.firstnumber + $scope.secondnumber;
        //$scope.Sub = $scope.firstnumber - $scope.secondnumber;
        //alert($scope.opt);

        $scope.result = eval($scope.firstnumber + $scope.opt + $scope.secondnumber)

    }
});
