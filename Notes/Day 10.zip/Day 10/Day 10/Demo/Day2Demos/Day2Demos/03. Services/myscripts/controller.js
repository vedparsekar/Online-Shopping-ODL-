﻿/// <reference path="C:\Users\ruena\Desktop\MVC + Angular JS\Day 2\Demo\Day2Demos\Day2Demos\Scripts/angular.js" />
/// <reference path="../../Scripts/angular.js" />

angular.module("factoryApp")
.controller("NumberController", function ($scope, MathService) {

    $scope.GetResult = function () {
        if ($scope.opt == "+") {
            $scope.result = MathService.Add($scope.firstnumber, $scope.secondnumber);
        }
        if ($scope.opt == "-") {
            $scope.result = MathService.Sub($scope.firstnumber, $scope.secondnumber);
        }
        if ($scope.opt == "*") {
            $scope.result = MathService.Multiply($scope.firstnumber, $scope.secondnumber);
        }
        if ($scope.opt == "/") {
            $scope.result = MathService.Div($scope.firstnumber, $scope.secondnumber);
        }
        
    }

})