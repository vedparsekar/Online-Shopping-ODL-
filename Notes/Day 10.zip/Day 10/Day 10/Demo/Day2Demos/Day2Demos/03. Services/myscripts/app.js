﻿/// <reference path="C:\Users\ruena\Desktop\MVC + Angular JS\Day 2\Demo\Day2Demos\Day2Demos\Scripts/angular.js" />


var app = angular.module("factoryApp", []);
app.service("MathService", function ()
{
    //var x = {};

    this.Add = function(q,z)
    {
        return q + z;
    }

    this.Sub = function (q, z) {
        return q - z;
    }

    this.Multiply = function (q, z) {
        return q * z;
    }

    this.Div = function (q, z) {
        return q / z;
    }

    //return x;

})

