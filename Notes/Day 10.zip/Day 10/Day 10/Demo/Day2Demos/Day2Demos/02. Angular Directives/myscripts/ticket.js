﻿/// <reference path="../../Scripts/angular.js" />
var app = angular.module("myApp", []);

app.controller("ticketController", function ($scope) {
    $scope.passengers = [
        { id: 123, name: "Ved", startplace: "Mapusa", endplace: "Panjim", price: 500,status:true},
        { id: 124, name: "John", startplace: "Mapusa", endplace: "Panjim", price: 700, status: true },
        { id: 125, name: "Jordan", startplace: "Panjim", endplace: "Vasco", price: 600, status: true },
        { id: 126, name: "Eashan", startplace: "Mapusa", endplace: "Panjim", price: 400, status: false },
        { id: 127, name: "Gaurish", startplace: "Mapusa", endplace: "Vasco", price: 500, status: true },
        { id: 128, name: "Shubham", startplace: "Vasco", endplace: "Panjim", price: 400, status: true },
        { id: 129, name: "Mandar", startplace: "Mapusa", endplace: "Vasco", price: 600, status: true }

    ];
})