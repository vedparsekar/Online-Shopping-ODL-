﻿
angular.module("myApp", [])
        .controller("CountryController", function ($scope) {
            $scope.country = {
                name: "India",
                capital: "Delhi",
                flag: "Images/India.png"
            };
        });