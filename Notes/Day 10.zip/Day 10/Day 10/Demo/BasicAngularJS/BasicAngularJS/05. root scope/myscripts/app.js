﻿var app = angular.module("myApp", [])

app.controller("BlueController", function ($scope, $rootScope) {
    $scope.favColor = "Blue",
    $rootScope.color = "White"
})

app.controller("RedController", function ($scope) {
    $scope.favColor = "Red"
})