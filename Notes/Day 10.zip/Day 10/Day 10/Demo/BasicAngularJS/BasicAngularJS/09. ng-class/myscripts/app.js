﻿var myApp = angular.module('myApp', []);

myApp.controller('ProductController', ['$scope',function ($scope) {
    $scope.products = [
      {
          'name': 'Xbox',
          'clearance': true,
          'price': 49.99,
      },
      {
          'name': 'Xbox 360',
          'clearance': false,
          'salesStatus': 'old',
          'price': 99.99,
      },
      {
          'name': 'Xbox One',
          'clearance': true,
          'salesStatus': 'new',
          'price': 399.99,
      },
      {
          'name': 'PS2',
          'clearance': true,
          'price': 49.99,
      },
      {
          'name': 'PS3',
          'salesStatus': 'old',
          'price': 99.99,
      },
      {
          'name': 'PS4',
          'salesStatus': 'new',
          'price': 399.99,
      }
    ]
}])