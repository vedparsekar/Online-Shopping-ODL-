﻿var app = angular.module("myApp", [])

app.controller("CountryController", function ($scope) {
    $scope.name = "India";
    $scope.iso = "INR"
})

app.controller("StateController", function ($scope) {
    $scope.name = "Goa";
})

app.controller("CityController", function ($scope) {
    $scope.name = "Panjim";
})