﻿var myApp = angular.module('myApp', []);

myApp.controller('EmployeeController', ['$scope',function ($scope) {
    $scope.employees = [
      {
          'name': 'Sam',
          'isPermanent': true,
          'salary': 49.99,
      },
      {
          'name': 'John',
          'isPermanent': false,
          'salary': 99.99,
      },
      {
          'name': 'Tom',
          'isPermanent': false,
          'salary': 399.99,
      },
      {
          'name': 'Ron',
          'isPermanent': true,
          'salary': 49.99,
      },
      {
          'name': 'Perry',
          'isPermanent': false,
          'salary': 99.99,
      },
      {
          'name': 'Sandy',
          'isPermanent': true,
          'salary': 399.99,
      }
    ]
}])