﻿var app = angular.module("myApp", [])

app.controller("PersonController", function ($scope) {
    $scope.firstName = "John",
    $scope.lastName = "Smith"
})