﻿// Storing a single constant value
var app = angular.module('myApp', []);

app.value('appName', 500);
app.constant('StringApp','My App')
//Instead of
//var appName = "My App";

// Now we inject our constant value into a test controller
app.controller('TestCtrl', ['appName','StringApp','$scope', function TestCtrl(appName,StringApp, $s) {
    $s.appName = appName;
    $s.appConstant = StringApp;
}]);




