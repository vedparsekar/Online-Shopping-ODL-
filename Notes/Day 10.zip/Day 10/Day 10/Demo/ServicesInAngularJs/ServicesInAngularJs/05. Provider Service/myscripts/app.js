﻿var application = angular.module('mainApp', []);

application.provider('message', function () {
    var temp = null;

    this.messageFromConfig = function (value) {
        temp = value;
    },

    this.$get = function () {
        return {
            messageFromProvider: temp
        }
    }
});

application.config(function (messageProvider) {
    messageProvider.messageFromConfig("Hello World!")
});

application.controller('myController', function ($scope, message) {
    $scope.greetMessage = message.messageFromProvider;
});