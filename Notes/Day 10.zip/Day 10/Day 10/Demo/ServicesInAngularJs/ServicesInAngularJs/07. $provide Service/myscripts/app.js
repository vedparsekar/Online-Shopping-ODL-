﻿/// <reference path="C:\Users\ruena\Desktop\MVC + Angular JS\Day 2\Demo\ServicesInAngularJs\ServicesInAngularJs\Scripts/angular.js" />

var mainApp = angular.module("mainApp", []);

mainApp.config(function ($provide) {
    $provide.factory('CalcService', function () {
        var factory = {};

        factory.add = function (a, b) {
            return a + b
        }

        factory.multiply = function (a, b) {
            return a * b
        }
        return factory;
    });
})


mainApp.controller('CalcController', function ($scope, CalcService) {
    $scope.square = function () {
        $scope.result = CalcService.multiply($scope.number, $scope.number);
    }
});