﻿var mainApp = angular.module("mainApp", []);

mainApp.service('CalcService', function () {
    this.add = function (a, b) {
        return a + b
    }

    this.multiply = function (a, b) {
        return a * b
    }
});

mainApp.controller('CalcController', function ($scope, CalcService) {
    $scope.square = function () {
        $scope.result = CalcService.multiply($scope.number, $scope.number);
    }
});