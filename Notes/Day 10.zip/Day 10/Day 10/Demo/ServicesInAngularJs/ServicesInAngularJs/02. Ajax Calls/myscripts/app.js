﻿/// <reference path="D:\Ruena\Technology Preparations\AngularJs\PowerPoints\Day 3\Demos\ServicesInAngularJs\ServicesInAngularJs\Scripts/angular.js" />

var app = angular.module('myApp', []);
app.controller('EmployeeController', function ($scope, $http) {
    $http(
    {
        method: "GET",
        url: "EmployeeData.txt"
    })
    .then(function onSuccess(response) {
        $scope.Employee = response.data;
    }, function onError(response) {
        alert("Error Occurred!")
    })






    /*
        //1.
        //$http.get()
        //Syntax - HttpPromise $http.get(url)

        $http.get("EmployeeData.txt")
             .then(function onSuccess(response) {
                    $scope.Employee = response.data;
                 }, function onError(response) {
                     alert("Error Occurred!")
                 })


        //2.
        //$http.post()
        //HttpPromise $http.post(url, dataToSubmit);

         var promise = $http.post('/demo/submitData', { message: 'Hello World!' });

         promise.success(function onSuccess(response) {
                    $scope.Employee = response.data;
                 });
                 
         promise.error(function onError(response) {
                     alert("Error Occurred!")
                 });
    */
})