﻿using System.Collections.Generic;

namespace OrderSales.DTO
{
    public class CustomerDTO
    {
        public CustomerDTO()
        {
            Orders = new List<OrderDTO>();
        }

        public int CustomerId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string City { get; set; }
        public string ContactNo { get; set; }
        public string ImagePath { get; set; }

        public List<OrderDTO> Orders { get; set; }
    }
}
