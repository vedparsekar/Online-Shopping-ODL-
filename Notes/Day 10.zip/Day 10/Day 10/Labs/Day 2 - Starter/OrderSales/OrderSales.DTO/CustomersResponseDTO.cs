﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OrderSales.DTO
{
    public class CustomersResponseDTO : BaseResponseDTO
    {
        public List<CustomerDTO> Customers { get; set; }
    }
}
