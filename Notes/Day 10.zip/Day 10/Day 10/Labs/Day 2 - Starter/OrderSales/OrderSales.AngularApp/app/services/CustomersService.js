﻿angular.module("odl.customersService", [])
.factory("customersService", ["$http", function ($http) {
    //Makes call to MVC Action Method -Returns JSON
    var f = {};
    f.getCustomers = function () {
        var promise = $http({
            url: "/Customers/GetCustomers",
            method: "GET"
        });
        return promise;
    }
    return f;
}])