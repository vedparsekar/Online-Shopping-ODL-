﻿using System;
using System.Collections.Generic;
using System.Web.Mvc;
using OrderSales.AngularApp.ViewModels;
using OrderSales.DTO;
using OrderSales.Manager;

namespace OrderSales.AngularApp.Controllers
{
    public class CustomersController : Controller
    {
        private ICustomerServiceManager customerManager;

        public CustomersController()
        {
            customerManager = CustomerServiceManager.NewCustomerServiceManager;
        }

        /// <summary>
        /// Main Action - This will Display the Initial Page
        /// </summary>
        public ActionResult Index()
        {
            return View();
        }

        #region Actions returning partial views


        public PartialViewResult _GetAllCustomers()
        {
            return PartialView();
        }

        #endregion

        #region Actions performing CRUD, returning JSON - will be called by AngularJs Services

        // GET: Customers
        public JsonResult GetCustomers()
        {
            CustomersResponseDTO result = customerManager.GetCustomers();
            return Json(result, JsonRequestBehavior.AllowGet);
        }

        #endregion
    }
}