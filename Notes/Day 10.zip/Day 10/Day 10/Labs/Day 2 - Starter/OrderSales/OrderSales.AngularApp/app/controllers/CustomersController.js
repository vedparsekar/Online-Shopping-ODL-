﻿angular.module("odl.CustomersController", [])

.controller("CustomersController", ["customersService", "$scope",
function (customersService, $scope) {
    var promise = customersService.getCustomers();
    promise.then(function (serverResponse) {
        //console.log(serverResponse);

        var details = serverResponse.data;
        if (details.IsSuccess) {
            $scope.Customers = details.Customers;

            $scope.c =details.Customers.Orders[1];
        }
        else {
            alert("Error: " + details.Message);
        }

    }, function (err) {
        alert('Error in Request');
    });
}])