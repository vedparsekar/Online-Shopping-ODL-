﻿/// <reference path="../Scripts/angular.js" />
angular.module("odl.customersApp", ["odl.customersService", "odl.CustomersController"]);