﻿using System;
using System.Collections.Generic;
using System.Data.Linq;
using System.Linq;
using OrderSales.Entities;

namespace OrderSales.Repository
{
    public interface ICustomerRepository
    {
        IEnumerable<CUSTOMER> GetCustomers();

        List<ORDER> GetCustomerOrders(int customerId);

    }

    public class CustomerRepository : ICustomerRepository
    {
        public static ICustomerRepository NewCustomerRepository
        {
            get
            {
                return new CustomerRepository();
            }
        }

        #region GET Methods

        /// <summary>
        /// Returns all Customers
        /// </summary>
        public IEnumerable<CUSTOMER> GetCustomers()
        {
            using (SalesDataContext context = new SalesDataContext())
            {
                try
                {
                    return context.CUSTOMERs.ToList();
                }
                catch (Exception)
                {
                    throw;
                }
            }
        }

        /// <summary>
        /// Method to return all orders of a Customer
        /// </summary>
        public List<ORDER> GetCustomerOrders(int customerId)
        {
            using (SalesDataContext context = new SalesDataContext())
            {
                try
                {
                    //Enabling eager loading - for Products
                    DataLoadOptions loadOptions = new DataLoadOptions();
                    loadOptions.LoadWith<ORDER>(o => o.PRODUCT);
                    context.LoadOptions = loadOptions;

                    return context.ORDERs
                                  .Where(o => o.CUSTOMERID == customerId)
                                  .ToList();
                }
                catch (Exception)
                {
                    throw;
                }
            }
        } 

        #endregion

    }
}
