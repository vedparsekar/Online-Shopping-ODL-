﻿using System;
using System.Collections.Generic;
using OrderSales.DTO;
using OrderSales.Entities;
using OrderSales.Repository;

namespace OrderSales.Manager
{
    public interface ICustomerServiceManager
    {
        CustomersResponseDTO GetCustomers();

    }

    public class CustomerServiceManager : ICustomerServiceManager
    {
        private ICustomerRepository _customerRepository;

        public CustomerServiceManager(ICustomerRepository customerRepository)
        {
            this._customerRepository = customerRepository;
        }

        public static ICustomerServiceManager NewCustomerServiceManager
        {
            get
            {
                return new CustomerServiceManager(CustomerRepository.NewCustomerRepository);
            }
        }

        #region GET Methods

        /// <summary>
        /// Return List of customers and orders
        /// </summary>
        public CustomersResponseDTO GetCustomers()
        {
            CustomersResponseDTO customerDTO = new CustomersResponseDTO();

            try
            {
                customerDTO.Customers = new List<CustomerDTO>();

                //Load Customers
                foreach (var cust in _customerRepository.GetCustomers())
                {
                    CustomerDTO newCustomer = new CustomerDTO
                    {
                        CustomerId = cust.CUSTOMERID,
                        FirstName = cust.CUSTOMERFIRSTNAME,
                        LastName = cust.CUSTOMERLASTNAME,
                        City = cust.CUSTOMERCITY,
                        ContactNo = cust.CUSTOMERCONTACT,
                        ImagePath = cust.CUSTOMERIMAGEPATH
                    };

                    //Load Orders
                    foreach (var order in _customerRepository.GetCustomerOrders(cust.CUSTOMERID))
                    {
                        newCustomer.Orders.Add(new OrderDTO
                        {
                            OrderId = order.ORDERID,
                            ProductName = order.PRODUCT.PRODUCTNAME,
                            Quantity = order.ORDERQUANTITY ?? 0,
                            Price = order.ORDERPRICE ?? 0,
                            Total = (order.ORDERQUANTITY ?? 0) * (order.ORDERPRICE ?? 0)
                        });
                    }

                    customerDTO.Customers.Add(newCustomer);
                }

                customerDTO.IsSuccess = true;
            }
            catch (Exception ex)
            {
                //Log Exception
                customerDTO.ErrorNo = -999;
                customerDTO.Message = ex.Message;
            }

            return customerDTO;
        }

        #endregion
       
    }
}
