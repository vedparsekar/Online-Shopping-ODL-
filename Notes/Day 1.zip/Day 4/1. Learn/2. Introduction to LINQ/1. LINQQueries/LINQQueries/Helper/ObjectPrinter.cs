﻿using System;
using System.Collections;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;
using System.Collections.Generic;
using LINQQueries.DataModels;

namespace LINQQueries.Helper
{
    /// <summary>
    /// Helper Class to print public properties of any Object
    /// </summary>
    public class ObjectPrinter
    {
        /// <summary>
        /// Prints Entire Collection
        /// </summary>
        public static void PrintCollection(object collection)
        {
            if (collection is IEnumerable)
            {
                foreach (object element in collection as IEnumerable)
                {
                    PrintObject(element);
                    Console.WriteLine();
                }
            }
        }

        /// <summary>
        ///Print Single Object
        /// </summary>
        public static void PrintObject(object element)
        {
            PropertyInfo[] allProperties = element.GetType().GetProperties(BindingFlags.Public | BindingFlags.Instance | BindingFlags.GetProperty);
            foreach (PropertyInfo pi in allProperties)
            {
                //For Groupings
                if (pi.PropertyType.GetGenericArguments().Any())
                {
                    var res = pi.PropertyType.GetGenericTypeDefinition();

                    PrintCollection(pi.GetValue(element));
                }
                else
                {
                    Console.WriteLine("{0}:\t{1}", pi.Name, pi.GetValue(element));
                }
            }
        }

        /// <summary>
        /// Print values of Primitive collections
        /// </summary>
        public static void PrintPrimitives<T>(IEnumerable<T> list) where T : struct
        {
            list.ToList().ForEach(l => Console.WriteLine(l));
        }

        /// <summary>
        /// Print Group Collections
        /// </summary>
        public static void PrintGroup<K, V>(IGrouping<K, V> group)
        {
            Console.WriteLine("==============================================");
            Console.WriteLine("Category in {0}", group.Key);
            Console.WriteLine("# of Products:\t{0}", group.Count());
            Console.WriteLine("----------------------------------------------");

            PrintCollection(group);
        }
    }
}
