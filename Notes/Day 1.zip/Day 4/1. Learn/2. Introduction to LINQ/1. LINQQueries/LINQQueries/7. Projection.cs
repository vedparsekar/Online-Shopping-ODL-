﻿using LINQQueries.DataModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using LINQQueries.Helper;

namespace LINQQueries
{
    public class Projection
    {
        private static OrderContext context = new OrderContext();

        /// <summary>
        /// This sample uses multiple from clauses so that filtering on customers can
        /// be done before selecting their orders.  This makes the query more efficient by
        /// not selecting and then discarding orders for customers outside of Washington.
        /// </summary>
        public static void UsingQueryOperator()
        {
            DateTime cutoffDate = new DateTime(1997, 1, 1);

            var myOrders = from c in context.Customers
                           where c.City == "Panjim"
                           from o in context.Orders
                           where c.CustomerId == o.CustomeId && o.OrderDate >= cutoffDate
                           select new { CustomerFirstName = c.FirstName, OrderID = o.OrderId, o.OrderDate };
        }

        public static void SelectManyUsingLambda()
        {
            //IEnumerable<List<string>>petsQuery =  context.PetOwners.Select(po => po.Pets);
            IEnumerable<string> petsQuery = context.PetOwners.SelectMany(petOwner => petOwner.Pets);

            petsQuery.ToList().ForEach(s => Console.WriteLine(s));
        }

        public static void SelectManyUsingQuery()
        {
            IEnumerable<string> petsQuery = from owners in context.PetOwners
                                            from pet in owners.Pets
                                            select pet;

            petsQuery.ToList().ForEach(s => Console.WriteLine(s));
        }
    }
}
