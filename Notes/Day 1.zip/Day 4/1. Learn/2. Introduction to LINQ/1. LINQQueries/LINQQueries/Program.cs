﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LINQQueries
{
    class Program
    {
        static void Main(string[] args)
        {

            //BasicQuery.Query();
            //FilteringQuery.UsingQueryOperator();
            Grouping.UsingQueryOperator();

            //Grouping.HavingClause();
            //Quantifiers.UsingAll();
            Console.ReadKey();
        }
    }
}
