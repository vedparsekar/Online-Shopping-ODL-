﻿using LINQQueries.DataModels;
using LINQQueries.Helper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LINQQueries
{
    public class Partitioning
    {
        private static OrderContext context = new OrderContext();

        public static void TakeQuery()
        {
            IEnumerable<Product> prodQuery = context.Products.Where(p => p.UnitsInStock != 0)
                                                             .Take(5);

            ObjectPrinter.PrintCollection(prodQuery);
        }

        public static void SkipQuery()
        {
            IEnumerable<Product> prodQuery = context.Products.Where(p => p.UnitsInStock != 0)
                                                             .Skip(5).Take(5);

            ObjectPrinter.PrintCollection(prodQuery);
        }

        public static void TakeWhileQuery()
        {
            IEnumerable<Product> prodQuery = context.Products.Where(p => p.UnitsInStock != 0)
                                                             .TakeWhile(p => p.ProductName.Length < 10);

            ObjectPrinter.PrintCollection(prodQuery);
        }
    }
}
