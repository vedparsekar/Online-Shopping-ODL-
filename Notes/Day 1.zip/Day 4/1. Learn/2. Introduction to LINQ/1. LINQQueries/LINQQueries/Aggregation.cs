﻿using LINQQueries.DataModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LINQQueries
{
    public class Aggregation
    {
        private static OrderContext context = new OrderContext();

        public static void UsingAggregate()
        {
            int[] numbers = { 4, 6, 3, 7, 8, 1, 9, 12 };

            int result = numbers.Aggregate((n1, n2) => n1 * n2);

            Console.WriteLine(result);
        }
    }
}
