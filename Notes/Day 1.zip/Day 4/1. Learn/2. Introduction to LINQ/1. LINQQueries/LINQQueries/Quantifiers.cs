﻿using LINQQueries.DataModels;
using LINQQueries.Helper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LINQQueries
{
    public class Quantifiers
    {
        private static OrderContext context = new OrderContext();

        public static void UsingAllSimple()
        {
            int[] numbers = { 1, 11, 3, 19, 41, 65, 19 };

            bool onlyOdd = numbers.All(n => n % 2 == 1);

            Console.WriteLine("The list contains only odd numbers: {0}", onlyOdd);
        }

        public static void UsingAll()
        {
            var productGroups = from prod in context.Products
                                group prod by prod.Category into prodGroup
                                where prodGroup.All(p => p.UnitsInStock > 0)
                                select new { Category = prodGroup.Key, Products = prodGroup };


            ObjectPrinter.PrintCollection(productGroups);
        }

        public static void UsingAny()
        {
            var productGroups = from prod in context.Products
                                group prod by prod.Category into prodGroup
                                where prodGroup.Any(p => p.UnitsInStock == 0)
                                select new { Category = prodGroup.Key, Products = prodGroup };


            ObjectPrinter.PrintCollection(productGroups);
        }
    }
}
