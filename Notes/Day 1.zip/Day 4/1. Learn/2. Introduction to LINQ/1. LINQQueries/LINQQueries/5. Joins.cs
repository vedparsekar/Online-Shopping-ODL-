﻿using LINQQueries.DataModels;
using LINQQueries.Helper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LINQQueries
{
    public class Joins
    {
        private static OrderContext context = new OrderContext();

        public static void UsingQueryOperator()
        {
            var joinCust = from cust in context.Customers
                           join ord in context.Orders on cust.CustomerId equals ord.CustomeId
                           select new { cust.FirstName, cust.LastName, ord.OrderId, ord.OrderDate };

            ObjectPrinter.PrintCollection(joinCust);
        }

        public static void UsingLambda()
        {
            var joinCust = context.Customers.Join(context.Orders,
                                                  cust => cust.CustomerId,
                                                  ord => ord.CustomeId,
                                                  (cust, ord) => new { cust.FirstName, cust.LastName, ord.OrderId, ord.OrderDate });
            ObjectPrinter.PrintCollection(joinCust);
        }

        public static void MultipleJoins()
        {
            var joinCust = from cust in context.Customers
                           join ord in context.Orders on cust.CustomerId equals ord.CustomeId
                           join detail in context.OrderDetails on ord.OrderId equals detail.OrderId
                           select new { cust.FirstName, cust.LastName, ord.OrderId, ord.OrderDate,  detail.Quantity };

            ObjectPrinter.PrintCollection(joinCust);
        }

        /// <summary>
        /// Group Join - A join clause with an into expression is called a group join.
        /// </summary>
        public static void GroupJoin()
        {
            var joinCust = from cust in context.Customers
                           join ord in context.Orders on cust.CustomerId equals ord.CustomeId into co
                           select new { cust.FirstName, cust.LastName, Orders = co };

            foreach (var cust in joinCust)
            {
                Console.WriteLine("Customer Name : {0}", string.Join(" ", cust.FirstName, cust.LastName));
                ObjectPrinter.PrintCollection(cust.Orders);
            }
        }

        /// <summary>
        /// Left Join
        /// </summary>
        public static void LeftJoins()
        {
            var joinCust = from prod in context.Products
                           join detail in context.OrderDetails on prod.ProductId equals detail.ProductId into ordetails
                           from ord in ordetails.DefaultIfEmpty(new OrderDetail { OrderId = 0, ProductId = 0, Quantity =0 })
                           select new { prod.ProductName, ord.Quantity};

            ObjectPrinter.PrintCollection(joinCust);
        }


        public static void CrossJoin()
        {
            var prevOrders = from c in context.Customers
                             from o in context.Orders
                             where c.CustomerId == o.CustomeId && o.OrderDate < DateTime.Now
                             select new
                             {
                                 CustomerID = c.CustomerId,
                                 OrderID = o.OrderId,
                             };

            ObjectPrinter.PrintCollection(prevOrders);
        }
    }
}
