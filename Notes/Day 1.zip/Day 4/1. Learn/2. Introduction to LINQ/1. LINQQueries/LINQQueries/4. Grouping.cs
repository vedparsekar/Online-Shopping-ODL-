﻿using LINQQueries.DataModels;
using LINQQueries.Helper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LINQQueries
{
    public class Grouping
    {
        private static OrderContext context = new OrderContext();

        public static void UsingQueryOperator()
        {
            var grpQuery = from p in context.Products
                           group p by p.Category;

            foreach (var grp in grpQuery)
            {
                Console.WriteLine("==============================================");
                Console.WriteLine("Category:\t{0}", grp.Key);
                Console.WriteLine("# of Products:\t{0}", grp.Count());
                Console.WriteLine("Max unit Price:\t{0}", grp.Max(p => p.UnitPrice));
                Console.WriteLine("----------------------------------------------");
                ObjectPrinter.PrintCollection(grp);
                Console.WriteLine();
            }
        }

        public static void UsingLambda()
        {
            var grpQuery = context.Products.GroupBy(p => p.Category);

            foreach (var grp in grpQuery)
            {
                Console.WriteLine("==============================================");
                Console.WriteLine("Category:\t{0}", grp.Key);
                Console.WriteLine("# of Products:\t{0}", grp.Count());
                Console.WriteLine("Max unit Price:\t{0}", grp.Max(p => p.UnitPrice));
                Console.WriteLine("----------------------------------------------");
                ObjectPrinter.PrintCollection(grp);
                Console.WriteLine();
            }
        }

        /// <summary>
        /// Grouping based on multiple columns
        /// </summary>
        public static void MultipleColumns()
        {
            var grpQuery = from c in context.Customers
                           group c by new { c.State, c.City };

            foreach (var grp in grpQuery)
            {
                Console.WriteLine("==============================================");
                Console.WriteLine("Customers in {0}, {1}", grp.Key.State, grp.Key.City);
                Console.WriteLine("# of Customers:\t{0}", grp.Count());
                Console.WriteLine("----------------------------------------------");
                ObjectPrinter.PrintCollection(grp);
                Console.WriteLine();
            }
        }

        /// <summary>
        /// Grouping using element selector
        /// </summary>
        public static void ElementSelector()
        {
            var grpQuery = from c in context.Customers
                           group new { c.FirstName, c.LastName } by c.City;

            foreach (var grp in grpQuery)
            {
                Console.WriteLine("==============================================");
                Console.WriteLine("Customers in {0}", grp.Key);
                Console.WriteLine("# of Customers:\t{0}", grp.Count());
                Console.WriteLine("----------------------------------------------");
                ObjectPrinter.PrintCollection(grp);
                Console.WriteLine();
            }
        }

        /// <summary>
        /// Grouping based on multiple columns with Result selector
        /// </summary>
        public static void ResultSelector()
        {
            var grpQuery = from c in context.Customers
                           group c by new { c.State, c.City } into grp
                           select new { Key = grp.Key, Count = grp.Count(), Customers = grp };
            
            foreach (var grp in grpQuery)
            {
                Console.WriteLine("==============================================");
                Console.WriteLine("Customers in {0}, {1}", grp.Key.State, grp.Key.City);
                Console.WriteLine("# of Customers:\t{0}", grp.Count);
                Console.WriteLine("----------------------------------------------");

                ObjectPrinter.PrintCollection(grp.Customers);
                Console.WriteLine();
            }
        }

        /// <summary>
        /// Grouping using all Key, Element and Result Selectors; Similar to previous query
        /// </summary>
        public static void KeyElementResultSelectors()
        {
            var grpQuery = context.Customers.GroupBy(c => c.City,
                                                     c => new { c.FirstName, c.LastName },
                                                     (key, values) => new { Key = key, Count = values.Count(), CustomerNames = values });

            foreach (var grp in grpQuery)
            {
                Console.WriteLine("==============================================");
                Console.WriteLine("Customers in {0}", grp.Key);
                Console.WriteLine("# of Customers:\t{0}", grp.Count);
                Console.WriteLine("----------------------------------------------");
                ObjectPrinter.PrintCollection(grp.CustomerNames);
                Console.WriteLine();
            }
        }

        public static void HavingClause()
        {
            var grpQuery = from c in context.Customers
                           group c by c.City into grp
                           where grp.Count() > 2
                           select new { Key = grp.Key, Count = grp.Count(), Customers = grp };

            foreach (var grp in grpQuery)
            {
                Console.WriteLine("==============================================");
                Console.WriteLine("Customers in {0}", grp.Key);
                Console.WriteLine("# of Customers:\t{0}", grp.Count);
                Console.WriteLine("----------------------------------------------");
                ObjectPrinter.PrintCollection(grp.Customers);
                Console.WriteLine();
            }
        }
    }
}