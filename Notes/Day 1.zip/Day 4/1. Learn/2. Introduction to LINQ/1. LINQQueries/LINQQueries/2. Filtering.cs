﻿using LINQQueries.DataModels;
using LINQQueries.Helper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LINQQueries
{
    public class FilteringQuery
    {
        private static OrderContext context = new OrderContext();

		/// <summary>
        /// This sample uses the where clause to find all products that are out of stock."
		/// </summary>
        public static void UsingQueryOperator()
        {
            IEnumerable<Product> prodQuery = from p in context.Products
                                             where p.UnitsInStock == 0
                                             select p;

            ObjectPrinter.PrintCollection(prodQuery);
        }

        public static void UsingLambda()
        {
            IEnumerable<Product> prodQuery = context.Products.Where(p => p.UnitsInStock == 0);

            ObjectPrinter.PrintCollection(prodQuery);
        }

    }
}
