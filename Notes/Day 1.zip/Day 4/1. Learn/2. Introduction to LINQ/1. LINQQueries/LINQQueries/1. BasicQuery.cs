﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LINQQueries
{
    public class BasicQuery
    {
        public static void Query()
        {
            //1. Data
            int[] numbers = { 56, 34, 23, 12, 32, 98, 78, 65, 53, 17, 45 };

            //2. Query
            IEnumerable<int> numQuery = from n in numbers
                                        where (n % 2) == 0
                                        orderby n descending
                                        select n;

            //3. Execution
            foreach (int num in numQuery)
            {
                Console.WriteLine(num);
            }

            Console.ReadKey();
        }
    }
}
