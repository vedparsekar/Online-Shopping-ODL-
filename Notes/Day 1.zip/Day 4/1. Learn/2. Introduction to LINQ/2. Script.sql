create database OrdersDB
GO

USE OrdersDB
GO

create table CustomerType
(
CustomerTypeId int identity(1,1),
CustomerTypeName varchar(50) NOT NULL,
CONSTRAINT pk_CustomerType_CustomerTypeId PRIMARY KEY(CustomerTypeId)
)

create table Customer
(
CustomerId int IDENTITY(1,1),
FirstName varchar(50) NOT NULL,
LastName varchar(50) NOT NULL,
Title varchar(10),
CustomerTypeId int,
[Address] varchar(50),
City varchar(50),
[State] varchar(50),
Country varchar(50),
Pincode varchar(10),
Email varchar(50),
Phone varchar(15),
CONSTRAINT pk_Customer_CustomerId PRIMARY KEY(CustomerId),
CONSTRAINT fk_Customer_CustomerTypeId FOREIGN KEY(CustomerTypeId) REFERENCES CustomerType(CustomerTypeId)
)

create table Category
(
CategoryId int IDENTITY(1,1),
CategoryName varchar(50) NOT NULL,
[Description] varchar(max),
CONSTRAINT pk_Category_CategoryId PRIMARY KEY(CategoryId)
)

create table Product
(
ProductId int IDENTITY(1,1),
ProductName varchar(100) NOT NULL,
CategoryId int,
UnitPrice money NOT NULL,
UnitsInStock int NOT NULL,
UnitsOnOrder int,
ReorderLevel int,
Discontinued bit,
CONSTRAINT pk_Product_ProductId PRIMARY KEY(ProductId),
CONSTRAINT fk_Product_CategoryId FOREIGN KEY(CategoryId) REFERENCES Category(CategoryId)
)

create table [Order]
(
OrderId int IDENTITY(1,1),
CustomerId int,
OrderDate datetime NOT NULL,
RequiredDate datetime NOT NULL,
Remarks varchar(max),
CONSTRAINT pk_Order_OrderId PRIMARY KEY(OrderId ),
CONSTRAINT fk_Order_CustomerId FOREIGN KEY(CustomerId) REFERENCES Customer(CustomerId)
)

create table OrderDetail
(
OrderId int,
ProductId int,
UnitPrice money NOT NULL,
Quantity int NOT NULL,
Discount money,
CONSTRAINT pk_OrderDetail_OrderId_ProductId PRIMARY KEY(OrderId,ProductId),
CONSTRAINT fk_OrderDetail_OrderId FOREIGN KEY(OrderId) REFERENCES [Order](OrderId),
CONSTRAINT fk_OrderDetail_ProductId FOREIGN KEY(ProductId) REFERENCES Product(ProductId)
)

insert into CustomerType values('GOLD')
insert into CustomerType values('SILVER');
insert into CustomerType values('BRONZE');

insert into Customer values('Deepraj','Kanulkar','Mast.',1,'Dhargal','Pernem','Goa','India','403512','mail4deepraj@gmail.com','9921035744');
insert into Customer values('Xenio','Gracias','Mast.',2,'Borim','Ponda','Goa','India','403510','Xenio@gmail.com','3574435744');
insert into Customer values('Sudesh','Volvoikar','Mast.',3,'Siquerim','Panjim','Goa','India','403511','Sudesh@gmail.com','9443575744');
insert into Customer values('Satish','Wagle','Mast.',1,'Panjim','Panim','Goa','India','403520','Satish@gmail.com','9921094435');
insert into Customer values('Abhishek','Naik','Mast.',2,'Mandrem','Pernem','Goa','India','403521','Abhishek@gmail.com','9922109444');

insert into Category values('Electronics','All product related to electronics');
insert into Category values('Fashion','All product related to Fashion');
insert into Category values('Home&Furniture','All product related to Home&Furniture');
insert into Category values('Books&More','All product related to Books&More');

insert into Product values('Zenfone 2 ZE15ML',1,13000.00,500,10,3,0);
insert into Product values('One Plus 3T',1,30000.00,800,30,3,0);
insert into Product values('Xiomi Mi 5',1,24000.00,900,50,3,0);

insert into Product values('Woood Land Shoes',2,3000.00,300,10,2,0);
insert into Product values('Raymond Blazer',2,50000.00,100,30,3,0);
insert into Product values('IDE glass',2,4000.00,300,40,3,0);

insert into Product values('Prestige Omega Marble Tawa 26 cm diameter  (Aluminium, Non-stick)',3,490,300,10,2,0);
insert into Product values('Panipat Textile Hub Polyester Blue Floral Eyelet Door Curtain  (213 cm in Height, Pack of 2)',3,23452,100,30,3,0);
insert into Product values('Hikvision 2 MP HD Turbo Cameras With HD 4 Channel Home Security Camera  (NA GB)',3,467,300,40,3,0);

insert into Product values('Let Us c',4,452,300,10,2,0);
insert into Product values('THE MEGA YEARBOOK 2017 - Current Affairs & General Knowledge for Competitive Exams - 2nd Edition  (English, Paperback, Disha Experts)',4,455,100,30,3,0);
insert into Product values('Quantitative Aptitude For Competitive Examinations  (English, Paperback, R. S. Aggarwal)',4,5667,300,40,3,0);


insert into [Order] values(1,'03/06/2017','03/13/2017','keeep amount ready on delivery');
insert into [Order] values(2,'03/03/2017','03/09/2017','keeep amount ready on delivery');
insert into [Order] values(3,'02/22/2017','03/12/2017','keeep amount ready on delivery');
insert into [Order] values(4,'03/05/2017','03/10/2017','keeep amount ready on delivery');
insert into [Order] values(5,'02/25/2017','03/07/2017','keeep amount ready on delivery');

insert into OrderDetail values(1,1,13000,2,1000);
insert into OrderDetail values(2,3,24000,3,2000);
insert into OrderDetail values(3,4,3000,1,500);
insert into OrderDetail values(4,8,23452,2,1000);
insert into OrderDetail values(5,2,30000,2,2000);