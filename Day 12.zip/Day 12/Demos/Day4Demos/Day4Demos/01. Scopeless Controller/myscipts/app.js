﻿// before
angular.module('myApp', [])
  .controller('personController', function ($scope) {
      $scope.firstName = 'John';
      $scope.lastName = "Smith";
      $scope.hobbies = ["Painting", "Football", "Travelling"];

      $scope.getFullName = function () {
          $scope.fullName = $scope.firstName + " " + $scope.lastName
      }
  });


