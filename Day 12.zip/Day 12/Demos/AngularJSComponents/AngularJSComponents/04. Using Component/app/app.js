﻿/// <reference path="C:\Users\ruena\Documents\Visual Studio 2013\Projects\Ruena\Test Task\AngularJSComponents\AngularJSComponents\Scripts/angular.js" />

angular.module('componentDemoApp', [])

.controller('CountCtrl', function () {
    this.count = 4;
})

.component('counter', {
    bindings: {
        count: '='
    },
    controller: function () {
        function increment() {
            this.count++;
        }
        function decrement() {
            this.count--;
        }
        this.increment = increment;
        this.decrement = decrement;
    },
    templateUrl: "templates/counter-template.html"
})

.component('counterWithControllerAs', {
    bindings: {
        count: '='
    },
    controller: function () {
        function increment() {
            this.count++;
        }
        function decrement() {
            this.count--;
        }
        this.increment = increment;
        this.decrement = decrement;
    },
    controllerAs: "counter",
    templateUrl: "templates/counter-with-controlleras-template.html",
})


