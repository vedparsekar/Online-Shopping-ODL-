﻿Links:
Custom Directives
http://websystique.com/angularjs/angularjs-directives-tutorial/


Transclude
https://docs.angularjs.org/api/ng/directive/ngTransclude

