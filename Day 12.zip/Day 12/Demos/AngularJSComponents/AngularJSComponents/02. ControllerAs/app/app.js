﻿// before
angular.module('myApp',[])
  .controller('PersonController', function () {
      var self = this;

      this.firstName = 'John';
      this.lastName = "Smith";
      this.hobbies = ["Painting", "Football", "Travelling"];
  });

  
