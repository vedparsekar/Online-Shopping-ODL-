﻿var sampleApp = angular.module('sampleApp', ['ui.router']);

sampleApp.config(['$stateProvider', function ($stateProvider) {
    $stateProvider
        .state('home',
          {
              url: "/home",
             

          })
     

}]);
